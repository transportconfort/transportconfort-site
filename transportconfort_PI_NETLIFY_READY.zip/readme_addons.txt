
- /assets/hero-airport.jpg est utilisé en haut de la page Tarifs (fallback automatique sur /assets/hero-g6.png).
- Simulateur : toggle Course/MAD, MAD affiche un sélecteur de durée et applique la grille MAD (+20% nuit/WE).
- Forfaits aéroports ORY/CDG/BVA appliqués automatiquement selon les adresses + jour/nuit.
- Remise de lancement -15% appliquée sur le prix final, le prix normal est barré.
- Bouton 📅 ouvre le calendrier natif si disponible (showPicker).
- Calendly : en mode MAD → lien MAD ; sinon lien VTC. Préremplissage a1..a5.
